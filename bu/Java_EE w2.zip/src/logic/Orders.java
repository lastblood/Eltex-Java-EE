package logic;

import data.Credentials;
import data.Order;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.LinkedList;

public class Orders {
    private final LinkedList<Order> ordersCollection;
    private final HashMap<LocalDateTime, Order> timeOrderMap;

    public Orders(LinkedList<Order> collection) {
        ordersCollection = collection;
        timeOrderMap = new HashMap<>();
        ordersCollection.forEach(x -> timeOrderMap.put(x.getCreateTime(), x) );
    }

    public Orders() {
        ordersCollection = new LinkedList<>();
        timeOrderMap = new HashMap<>();
    }


    synchronized void add(Order obj) {
        ordersCollection.add(obj);
    }

    synchronized void delete(Order obj) {
        ordersCollection.remove(obj);
    }


    synchronized void checkout(Duration duration, Credentials userInfo, ShoppingCart cart) {
        ordersCollection.add(new Order(duration, userInfo, cart));
    }

    synchronized void processing() {
        ordersCollection.removeIf(o ->
                o.getStatus().equals(Order.STATUSES.PROCESSED) ||
                o.getExpectedTime().compareTo(LocalDateTime.now()) < 0
        );
    }
}