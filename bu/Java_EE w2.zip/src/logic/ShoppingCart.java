package logic;


import data.Product;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class ShoppingCart {
    private ArrayList<Product> productsCollection;

    public ShoppingCart() {
        productsCollection = new ArrayList<>();
    }

    public ShoppingCart(ArrayList<Product> productsCollection) {
        this.productsCollection = productsCollection;
    }


    public void add(Product product) {
        productsCollection.add(product);
    }

    public void delete(Product product) {
        productsCollection.remove(product);
    }


    public String showAll() {
        return productsCollection.stream().map(Object::toString).collect(Collectors.joining(", "));
    }
}
