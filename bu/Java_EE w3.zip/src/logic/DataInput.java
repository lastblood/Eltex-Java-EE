package logic;

public interface DataInput {
    String[] input();
}
