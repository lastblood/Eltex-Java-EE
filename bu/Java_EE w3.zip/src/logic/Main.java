package logic;

import data.Credentials;
import data.Order;
import data.Product;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        System.out.print("Enter count of products: ");
        Scanner scan = new Scanner(System.in);
        int count = scan.nextInt();

        ArrayList<Product> products = new ArrayList<>();

        for (int i = 0; i < count; i++) {
            try {
                boolean random = false;
                System.out.print("Enter product #" + (i+1) + " type: ");
                String s = scan.next();
                if(s.equalsIgnoreCase("random")) {
                    s = new String[]{"tea", "coffee"}[(int) Math.round(Math.random())];
                    random = true;
                }

                Product p = new ProductFactory(s).create();
                if(random)
                    p.create();
                else
                    p.update();

                p.read();

                products.add(p);
            } catch (Exception e) {
                System.err.println("Input exception");
            }
        }

        Credentials credentials = new Credentials();
        credentials.setFirstName("FirstName");
        credentials.setLastName("LastName");
        credentials.setPatronymic("Patronymic");
        credentials.setEmail("email@email.com");

        ShoppingCart<Product> cart = new ShoppingCart<>();
        for (Product temp : products) {
            System.out.println("How many " + temp.getName() + " need to be added in order?");
            int countOfProduct = scan.nextInt();
            for (int j = 0; j < countOfProduct; j++)
                cart.add(temp);
        }

        Orders<Order> orders = new Orders<>();

        System.out.println("Input time for access order (in seconds): ");
        orders.checkout(Duration.ofSeconds(scan.nextInt()), credentials, cart);


        for(int time = 1; true; time++) {
            Thread.sleep(1000);
            orders.check();
            System.out.println("After " + time + " seconds:\n" + orders.toString());
        }
    }
}
