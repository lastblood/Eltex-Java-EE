package logic;

import java.util.Scanner;

public class ConsoleInput {
    private ConsoleInput() {}

    private static Scanner scan = new Scanner(System.in);

    public static String[] input(String[] hints, int length) {
        String[] result = new String[length];
        if(hints.length < length) throw new IllegalArgumentException("hints.length < length");
        if(hints.length > length) System.err.println("WARNING: hints.length > length");

        for (int i = 0; i < length; i++) {
            System.out.print("Enter " + hints[i] + ": ");
            result[i] = scan.nextLine(); //TODO: check scan.next() method
        }

        return result;
    }

}