package logic;

import data.Product;

public class Main {
    public static void main(String[] args) {
        int count = Integer.parseInt(args[0]);
        String type = args[1];
        ProductFactory factory = new ProductFactory(type);

//        for (int i = 0; i < count; i++) {
        for (int i = 0; i < count; i++) {
            Product product = factory.create();

            product.update();

            //TODO: вывод через специальный класс
            System.out.println(product.read());
        }
    }
}
