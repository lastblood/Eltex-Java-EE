package data;

import logic.ConsoleInput;

public class CoffeeProduct extends Product {
    public enum BEAN_TYPES {
        ARABICA,
        ROBUSTA
    }

    private BEAN_TYPES beans;

    @Override
    public void create() {
        super.create();
        beans = BEAN_TYPES.values()[random.nextInt(2)];
    }

    @Override
    public void delete() {
        beans = null;
        super.delete();
    }

    private static final String[] hints = {"beans type (Arabica, Robusta)"};
    @Override
    public void update() {
        String t = ConsoleInput.input(hints, 1)[0];

        if(t.equalsIgnoreCase("a") || t.equalsIgnoreCase("arabica"))
            beans = BEAN_TYPES.ARABICA;
        else if(t.equalsIgnoreCase("r") || t.equalsIgnoreCase("robusta"))
            beans = BEAN_TYPES.ROBUSTA;
        else
            throw new IllegalArgumentException("Unknown sort of beans: " + t);

        super.update();
    }

    @Override
    public String toString() {
        return "data.CoffeeProduct{" +
                "beans=" + beans +
                "} " + super.toString();
    }

    public BEAN_TYPES getBeans() {
        return beans;
    }
}
